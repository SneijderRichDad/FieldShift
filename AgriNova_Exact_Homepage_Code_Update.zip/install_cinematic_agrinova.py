from pathlib import Path
import shutil

app=Path('app.js')
if not app.is_file():raise SystemExit('Run from FieldShift repository root: app.js is missing')
s=app.read_text(encoding='utf-8')
if 'function cinematicOverview(){' in s:raise SystemExit('Cinematic dashboard already installed. No edits made.')
if "dashboard:overview" not in s or 'function render(){' not in s or '<form id="searchForm"' not in s:
    raise SystemExit('Unexpected app structure; no files were changed.')
css=Path('agrinova-cinematic.css')
js=Path('cinematic-dashboard-snippet.js')
asset=Path('agrinova-assets/rwanda-landscape.webp')
if not css.exists() or not js.exists() or not asset.exists():
    raise SystemExit('Files not found. Extract the complete ZIP in your repo root before installing.')
shutil.copy2(app,'app.js.before-cinematic')
s=s.replace("import {validateStoryInput,validateStoryFile,isSupportedStoryVideo} from './lib/story-validation.js';", "import {validateStoryInput,validateStoryFile,isSupportedStoryVideo} from './lib/story-validation.js';\nimport './agrinova-cinematic.css';",1)
if "import './agrinova-cinematic.css'" not in s:raise SystemExit('Unexpected import line; no code saved.')
# Replace search field with screenshot-style brand/navigation only on dashboard.
import re
pat=r'<form id="searchForm".*?</form>'
mt=re.search(pat,s,flags=re.S)
if not mt: raise SystemExit('Header search block not found; no changes made.')
original=mt.group(0)
s=s[:mt.start()]+"${state.page==='dashboard'?cinematicTopNav():`"+original+"`}"+s[mt.end():]
# Preserve the existing search form on every non-dashboard page.
s=s.replace('dashboard:overview','dashboard:cinematicOverview',1)
s=s.replace('function render(){',"function render(){document.body?.classList?.toggle('agrinova-dashboard',state.page==='dashboard');",1)
pos=s.index('function render(){')
s=s[:pos]+js.read_text(encoding='utf-8')+'\n'+s[pos:]
Path('public/agrinova-assets').mkdir(parents=True, exist_ok=True)
shutil.copy2(asset,Path('public/agrinova-assets/rwanda-landscape.webp'))
app.write_text(s,encoding='utf-8')
print('AgriNova cinematic dashboard integrated. Backup: app.js.before-cinematic')
print('Next: npm run build && npm test')
