# AgriNova — Compact Cinematic Workspaces

## What this release changes

- Reduces the visible navigation to **five primary workspaces**:
  1. Dashboard (existing cinematic dashboard)
  2. Farm & Rotation (registered farms, rotation planning, greenhouse)
  3. Climate & Map (NASA historical climate, what-if simulator, Rwanda district map, research)
  4. AI & Crop Care (Nova AI, photo review, help)
  5. Market & Community (real marketplace, discussions, private messages, farmer stories)
- Adds a consistent midnight navy / emerald / teal / gold glass-card theme across the application.
- Gives existing individual feature pages compact workspace tabs and a return-to-workspace link.
- Preserves existing routing, Supabase tables, authentication, stored farm records, NASA API functions, and current AI provider configuration.
- Makes no claims that any disconnected provider is live. No fabricated market or weather values are inserted.

## Install

Upload this ZIP to the root of `SneijderRichDad/FieldShift`, or place the Python file beside `app.js` and `styles.css`.

```bash
cd /workspaces/FieldShift
git pull origin main
unzip -o AgriNova_Compact_Cinematic_Workspaces.zip
python3 install_compact_workspaces.py
npm run build && npm test
```

**Only after build and tests succeed:**

```bash
git add app.js styles.css
git commit -m "Consolidate AgriNova into five cinematic workspaces"
git push origin main
npx wrangler pages deploy dist --project-name=fieldshift-pages --branch=main
```

## Verify

1. Open Dashboard, then each of the four new workspaces.
2. Select My Farms from Farm & Rotation; check registered farms still load.
3. Select Climate history and Climate Simulator; verify data is labeled as historical, not forecast.
4. Confirm AI Advisor reports missing sign-in or provider configuration instead of claiming a generated answer.
5. Open Market & Community and check the marketplace, community and messages.
6. Change between English, Kinyarwanda and French. Some deeply nested feature labels remain English and need a later translation pass.
7. Check mobile layout and keyboard navigation.

## Rollback

Backups are created as `app.js.before_compact_workspaces` and `styles.css.before_compact_workspaces`.

```bash
cp app.js.before_compact_workspaces app.js
cp styles.css.before_compact_workspaces styles.css
npm run build && npm test
```

The installer intentionally aborts if the application structure differs from the version inspected on 2026-11-15. No database migrations are required.
