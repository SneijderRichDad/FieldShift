from pathlib import Path
import shutil

root=Path.cwd()
app=root/'app.js'
css=root/'styles.css'
if not (app.exists() and css.exists()):
    raise SystemExit('Run this installer at FieldShift repository root (app.js/styles.css missing).')
s=app.read_text('utf-8')
c=css.read_text('utf-8')
MARK='AGRINOVA_COMPACT_WORKSPACES_V1'
if MARK in s:
    raise SystemExit('Compact Workspaces is already installed. No changes made.')

# Abort before modifying any file if a required anchor cannot be matched.
anchors=['const navItems=',';\nconst titleFor=', 'function render(){','function saveState(){', 'function layout(content)', '${content}<div class="footer">', "${state.page==='dashboard'?cinematicTopNav():", 'document.addEventListener(\'click\'']
for x in anchors:
    if x not in s: raise SystemExit(f'Expected code changed: {x}. No changes made.')
backup=root/'app.js.before_compact_workspaces'
if not backup.exists(): shutil.copyfile(app,backup)
css_backup=root/'styles.css.before_compact_workspaces'
if not css_backup.exists(): shutil.copyfile(css,css_backup)

start=s.index('const navItems=')
end=s.index(';\nconst titleFor=',start)+1
s=s[:start]+"""const navItems=[
 ['dashboard','⌂','Dashboard'],
 ['hub-farm','🌾','Farm & Rotation'],
 ['hub-climate','☁','Climate & Map'],
 ['hub-ai','✧','AI & Crop Care'],
 ['hub-connect','♧','Market & Community']
];"""+s[end:]
s=s.replace('const titleFor=page=>({',"const titleFor=page=>({'hub-farm':'My farm and crop planning','hub-climate':'Climate and field intelligence','hub-ai':'Farming intelligence and crop care','hub-connect':'Farmers, markets and messages',",1)
s=s.replace("${state.page==='dashboard'?cinematicTopNav():", "${state.page==='dashboard'?workspaceTopNav():",1)
# This targeted removal preserves all existing old functional pages and their forms.
s=s.replace('${content}<div class="footer">','${workspaceTabs()}${content}<div class="footer">',1)
s=s.replace("state.page===id?'active':''", "activeWorkspace(state.page)===id?'active':''",1)
# No need for sidebar's More to Explore marker; only 5 hub labels remain.
s=s.replace("${index===8?'<div class=\"nav-label\">MORE TO EXPLORE</div>':''}","",1)
old="function render(){document.body?.classList?.toggle('agrinova-dashboard',state.page==='dashboard');({farms:farmsPage,dashboard:cinematicOverview,community,messages:novaChatPage,rotation,climate,explorer,research,market,advisor,profile,simulation,greenhouse,scanner,help,about,stories,admin,account,notifications}[state.page]||overview)()}"
new="function render(){document.body?.classList?.toggle('agrinova-dashboard',true);({['hub-farm']:hubFarm,['hub-climate']:hubClimate,['hub-ai']:hubAI,['hub-connect']:hubConnect,farms:farmsPage,dashboard:cinematicOverview,community,messages:novaChatPage,rotation,climate,explorer,research,market,advisor,profile,simulation,greenhouse,scanner,help,about,stories,admin,account,notifications}[state.page]||cinematicOverview)()}"
if old not in s: raise SystemExit('Render signature changed; no changes saved.')
s=s.replace(old,new,1)

newfunctions=r'''
// AGRINOVA_COMPACT_WORKSPACES_V1
// The underlying original modules stay intact. We offer five navigational workspaces
// and visible sub-tabs to reach real functions without duplicating backend calls.
const agriWorkspaces={
 'hub-farm':[['farms','My farms'],['rotation','Crop rotation'],['greenhouse','Greenhouse planner']],
 'hub-climate':[['climate','Climate history'],['simulation','Climate simulator'],['explorer','Farm map'],['research','Research']],
 'hub-ai':[['advisor','AI assistant'],['scanner','Crop photo review']],
 'hub-connect':[['market','Marketplace'],['community','Community'],['messages','Farmer chat'],['stories','Farmer stories']]
};
function activeWorkspace(page){
 if(page==='dashboard')return page;
 for(const [hub,pages] of Object.entries(agriWorkspaces))if(page===hub||pages.some(([id])=>id===page))return hub;
 return page;
}
function workspaceTopNav(){
 return `<nav class="agri-workspace-topnav" aria-label="Main sections">${navItems.map(([id,icon,label])=>`<button type="button" class="agri-workspace-link ${activeWorkspace(state.page)===id?'active':''}" data-page="${id}"><span aria-hidden="true">${icon}</span> ${escapeHTML(label)}</button>`).join('')}</nav>`;
}
function workspaceTabs(){
 const group=activeWorkspace(state.page);
 if(!agriWorkspaces[group]||state.page===group)return '';
 return `<div class="agri-workspace-tabs" role="navigation" aria-label="Workspace tools"><button class="agri-tab-home" data-page="${group}">← Workspace</button>${agriWorkspaces[group].map(([id,label])=>`<button class="agri-tab ${state.page===id?'active':''}" data-page="${id}">${escapeHTML(label)}</button>`).join('')}</div>`;
}
function agriHubCard(icon,title,desc,route,footer='Open feature →'){
 return `<button type="button" class="agri-hub-card" data-page="${route}"><span class="agri-hub-symbol">${icon}</span><strong>${escapeHTML(title)}</strong><span>${escapeHTML(desc)}</span><b>${escapeHTML(footer)}</b></button>`;
}
function agriHubShell(kicker,heading,desc,items,note){
 layout(`<section class="agri-hub-heading"><span class="agri-hub-kicker">${kicker}</span><h2>${heading}</h2><p>${desc}</p></section><div class="agri-hub-grid">${items.join('')}</div>${note?`<p class="agri-hub-note">${note}</p>`:''}`);
}
function hubFarm(){
 const count=Array.isArray(state.farms)?state.farms.length:0;
 const nplans=Array.isArray(state.savedRotations)?state.savedRotations.length:0;
 agriHubShell('01 / YOUR LAND','Farm & Rotation','Manage your fields and plan better crop sequences in one workspace.',[
  agriHubCard('🌿','My registered farms',`${count} private farm record(s). Add fields and crop seasons.`, 'farms'),
  agriHubCard('🔄','Crop rotation studio',`${nplans} saved rotation plan(s). Compare illustrative options.`, 'rotation'),
  agriHubCard('🏡','Greenhouse planner','Explore seasonal greenhouse considerations.','greenhouse')
 ],'Rotation scores are educational, not scientifically validated yield forecasts.');
}
function hubClimate(){
 const rows=Array.isArray(state.climate)?state.climate:[];
 const climateLabel=state.climateStatus==='live'&&rows.length?`${rows.length} historical daily values loaded.`:'NASA observations not loaded yet.';
 agriHubShell('02 / EARTH OBSERVATION','Climate & Map','Historical climate, hypothetical scenarios and district navigation together.',[
  agriHubCard('🌦','Climate history',climateLabel,'climate'),
  agriHubCard('🌡','What-if simulator','Compare historical baselines against hypothetical temperature and rainfall changes.','simulation'),
  agriHubCard('🗺','Rwanda district explorer','Explore district locations and approximate reference coordinates.','explorer'),
  agriHubCard('🛰','Scientific sources','See credited NASA agricultural research and data descriptions.','research')
 ],'NASA POWER provides historical gridded estimates, not a live local forecast. Rwanda-only limitations remain in force.');
}
function hubAI(){
 agriHubShell('03 / AGRICULTURAL SUPPORT','AI & Crop Care','Ask questions and review crop photos in one clearly explained workspace.',[
  agriHubCard('✧','Ask AgriNova',state.auth?'Signed in. AI replies depend on the configured cloud provider.':'Sign in to access server AI; demo guidance is rule-based.','advisor'),
  agriHubCard('📷','Crop photo review','Upload a crop picture; model analysis needs a configured vision service.','scanner'),
  agriHubCard('🔒','Privacy & help','Understand evidence, data protection and limitations.','help')
 ],'AI advice is educational. Check important decisions with a local agronomist.');
}
function hubConnect(){
 const listings=Array.isArray(state.marketCloud)?state.marketCloud.filter(x=>x.country===state.country).length:0;
 agriHubShell('04 / PEOPLE & MARKETS','Market & Community','One place for agricultural trading, collaboration and conversations.',[
  agriHubCard('🛒','Nova Market',`${listings} real registered-user listing(s) in ${state.country}.`, 'market'),
  agriHubCard('🤝','Farmer community','Ask questions and share practical farming experiences.','community'),
  agriHubCard('💬','Farmer messages','Private conversations with other registered users.','messages'),
  agriHubCard('⭐','Farmer stories','See published experiences and their evidence labels.','stories')
 ],'No simulated buyers, fabricated prices, or invented farmer testimonials.');
}
'''
needle='function render(){'
i=s.index(needle)
s=s[:i]+newfunctions+'\n'+s[i:]

css_delta=r'''
/* AGRINOVA_COMPACT_WORKSPACES_V1 — shared cinematic visual system */
:root, [data-theme="dark"], [data-theme="mixed"] {
 --page-bg:#061d22;--panel-bg:#092d31;--top-bg:#051b22;
 --main-text:#effbf5;--sub-text:#b8d8cf;--line-color:rgba(69,224,184,.34);
 --input-bg:#10363a;--accent:#61f2bf;
}
[data-theme="light"]{
 --page-bg:#edf7f1;--panel-bg:#ffffff;--top-bg:#f8fff9;
 --main-text:#173e34;--sub-text:#4a7162;--line-color:#b7d8c7;
 --input-bg:#fbfffc;--accent:#146b51;
}
body,.shell,.main{background:var(--page-bg)!important;color:var(--main-text)}
.sidebar{background:linear-gradient(180deg,#031a21,#063c35)!important;border-right:1px solid rgba(72,220,171,.25)}
.topbar{background:var(--top-bg)!important;border-color:var(--line-color)!important;padding:8px clamp(14px,2vw,32px)!important;min-height:84px;height:auto!important;flex-wrap:wrap}
.main{max-width:1600px!important;padding:26px clamp(14px,3vw,40px) 80px!important}
.card,.market-live-card,.market-stats>div,.market-empty,.farm-record,.form-panel,.advisor-main,.nova-chat-shell{
 background:var(--panel-bg)!important;color:var(--main-text)!important;border:1px solid var(--line-color)!important;
 box-shadow:0 14px 38px rgba(0,0,0,.16),inset 0 1px 0 rgba(133,255,204,.06)!important;
 border-radius:19px!important;
}
.card h3,.market-live-head strong,.section-head h3,.page-title,.farm-intro h2,.market-hero h2,.advisor-intro h2{color:var(--main-text)!important}
.muted,.subtitle,.market-details,.farm-record p,.post p{color:var(--sub-text)!important}
.input,textarea,select,input{accent-color:var(--accent)}
.input,.country-select,.search{background:var(--input-bg)!important;color:var(--main-text)!important;border-color:var(--line-color)!important}
.input::placeholder,.search input::placeholder{color:var(--sub-text);opacity:.75}
.btn:not(.white),.nav.active,.nav:hover{transition:transform .15s ease,box-shadow .18s ease}
.btn:hover,.agri-hub-card:hover,.agri-workspace-link:hover{transform:translateY(-2px)}
.btn:focus-visible,.nav:focus-visible,.agri-hub-card:focus-visible,.agri-tab:focus-visible{outline:3px solid #e9c46a;outline-offset:3px}
.agri-workspace-topnav{display:flex;align-items:center;gap:5px;overflow-x:auto;max-width:min(840px,68vw);padding:4px 3px;scrollbar-width:thin}
.agri-workspace-link{border:1px solid transparent;background:transparent;color:var(--sub-text);font-size:12px;font-weight:800;white-space:nowrap;padding:11px 12px;border-radius:12px}
.agri-workspace-link.active,.agri-workspace-link:hover{border-color:var(--accent);color:var(--main-text);background:rgba(21,154,122,.19);box-shadow:0 0 16px rgba(66,247,191,.14)}
.agri-workspace-tabs{display:flex;flex-wrap:wrap;align-items:center;gap:8px;margin:0 0 20px;padding:11px;border:1px solid var(--line-color);background:var(--panel-bg);border-radius:16px}
.agri-tab,.agri-tab-home{padding:9px 13px;background:var(--input-bg);color:var(--main-text);border:1px solid var(--line-color);border-radius:999px;font-weight:750;font-size:12px}
.agri-tab.active{color:#041d1e;background:#61f2bf;border-color:#61f2bf}
.agri-hub-heading{margin:0 0 24px;padding:clamp(24px,4vw,48px);background:linear-gradient(115deg,rgba(3,39,43,.92),rgba(0,95,74,.64)),radial-gradient(circle at 85% 20%,rgba(255,206,94,.16),transparent 35%);border:1px solid var(--line-color);border-radius:26px;box-shadow:0 20px 55px rgba(0,0,0,.18)}
.agri-hub-kicker{color:#e6c16f;font-size:11px;font-weight:900;letter-spacing:2.5px}
.agri-hub-heading h2{font:800 clamp(30px,4.4vw,52px)/1.05 'Outfit',system-ui,sans-serif;margin:12px 0;color:#f5fff9}
.agri-hub-heading p{color:#d0e8de;font-size:15px;max-width:760px;line-height:1.65}
.agri-hub-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:20px}
.agri-hub-card{text-align:left;display:flex;flex-direction:column;gap:12px;min-height:205px;width:100%;padding:26px;background:linear-gradient(145deg,rgba(13,78,70,.85),rgba(7,42,49,.98));border:1px solid #36a98c;border-radius:23px;color:#fff;box-shadow:0 18px 36px rgba(0,0,0,.13);transition:transform .15s,border-color .15s,box-shadow .15s}
.agri-hub-card:hover{border-color:#80f9c8;box-shadow:0 0 22px rgba(27,210,160,.23)}
.agri-hub-symbol{font-size:36px}
.agri-hub-card strong{font:750 23px 'Outfit',sans-serif}
.agri-hub-card>span:not(.agri-hub-symbol){color:#c9dfd5;line-height:1.5;font-size:13px}
.agri-hub-card>b{color:#e9cf83;font-size:12px;margin-top:auto}
.agri-hub-note{border:1px solid var(--line-color);border-radius:12px;color:var(--sub-text);background:var(--panel-bg);padding:16px;margin-top:18px;font-size:12px;line-height:1.7}
[data-theme="light"] .agri-hub-heading{background:linear-gradient(105deg,#095248,#277c5d)}
@media(max-width:1050px){.agri-workspace-topnav{max-width:90vw}.topbar{gap:8px}}
@media(max-width:700px){.agri-hub-grid{grid-template-columns:1fr}.agri-workspace-topnav{max-width:calc(100vw - 65px)}.agri-workspace-link{padding:9px}.agri-hub-card{min-height:170px}.agri-hub-heading{padding:25px 19px}}
@media(prefers-reduced-motion:reduce){.agri-hub-card,.agri-workspace-link{transition:none}}
'''

# Append CSS; do not overwrite original component styles, API routes or DB code.
css.write_text(c+'\n'+css_delta,encoding='utf-8')
app.write_text(s,encoding='utf-8')
print('Installed 5 dashboard workspaces. Existing backend/modules preserved.')
print('Backups: app.js.before_compact_workspaces, styles.css.before_compact_workspaces')
print('Run: npm run build && npm test')
