AgriNova NovaX Lab About Us update

Extract ZIP at the root of the FieldShift Codespace.
Run: python3 install_novax_about.py
Run: npm run build && npm test
If tests pass: git add app.js agrinova-cinematic.css public/agrinova-assets/novax-lab-team.png
Then commit, push and deploy through Wrangler.

Includes the image provided by the user and real HTML cards based on that image.
No backend, authentication, database or climate endpoints modified.
