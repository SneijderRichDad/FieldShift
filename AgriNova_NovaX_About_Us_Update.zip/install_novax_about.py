from pathlib import Path
import shutil

root = Path.cwd()
app = root / 'app.js'
css = root / 'agrinova-cinematic.css'
src = Path(__file__).resolve().parent / 'novax-lab-team.png'
dst = root / 'public' / 'agrinova-assets' / 'novax-lab-team.png'
if not app.exists() or not css.exists():
    raise SystemExit('Run this installer in FieldShift repository root (app.js / agrinova-cinematic.css required).')
if not src.exists():
    raise SystemExit('Missing novax-lab-team.png. Extract the whole ZIP before running.')
s = app.read_text(encoding='utf-8')
a = s.find('function about(){')
b = s.find('\nfunction startSpeech()', a)
if a < 0 or b < 0:
    raise SystemExit('About page boundaries have changed. No files modified.')
if 'novax-about-hero' in s:
    raise SystemExit('Team NovaX About design is already installed. No files modified.')

new_about = r'''function about(){
 const founders=[
  ['MANZI Snejder Arsenal','Product & Vision Lead'],
  ['MUKUNZI Ally Muhadjir','Data & Platform Operations'],
  ['GISUBIZO Moise','Research & Field Insights'],
  ['KUNDWA KEZA Dalcia','Community & User Experience'],
  ['UMUTONIWASE Kenitha','UI/UX & Communication'],
  ['ISARO Sasha Salmah','Outreach & Documentation']
 ];
 const goals=[
  ['🌱','Improve crop rotation decisions.'],
  ['🌦','Connect farmers to climate and market intelligence.'],
  ['📍','Make guidance more accessible and localized.']
 ];
 layout(`<div class="novax-about">
   <section class="novax-about-hero" aria-label="Team NovaX Lab illustrated introduction">
     <img src="/agrinova-assets/novax-lab-team.png" loading="eager" alt="Team NovaX Lab: six co-founders and objectives, against an illustrated agricultural landscape of Rwanda" />
   </section>
   <div class="novax-about-heading"><div><span class="eyebrow">DEVELOPED BY TEAM NOVAX LAB</span><h2>Young innovators. Practical agricultural technology.</h2><p>We are building AgriNova to make crop planning, climate history and farmer connections easier to understand and use.</p></div><button class="btn secondary" data-page="dashboard">Explore AgriNova ↗</button></div>
   <div class="novax-about-columns">
     <section class="novax-about-section"><h3>♧ Our Team</h3><div class="novax-team-grid">${founders.map(([name,role])=>`<article class="novax-team-card"><span aria-hidden="true" class="novax-person-icon">♙</span><div><strong>${escapeHTML(name)}</strong><p>${escapeHTML(role)}</p></div></article>`).join('')}</div></section>
     <section class="novax-about-section"><h3>◎ Our Objectives</h3><div class="novax-goals">${goals.map(([icon,goal])=>`<div class="novax-goal"><span aria-hidden="true">${icon}</span><p>${escapeHTML(goal)}</p></div>`).join('')}</div></section>
   </div>
   <section class="novax-about-credits"><div><h3>Our mission</h3><p>Support informed crop-rotation planning by combining farmer records, historical climate observations, educational agronomy guidance and farmer-to-farmer connections.</p><p class="muted">Team responsibilities shown here are proposed roles for the co-founders to confirm.</p></div><div><h3>Project credits</h3><p>NASA POWER historical climate estimates; Supabase, Cloudflare Pages, GitHub and OpenStreetMap. The illustrative hero artwork is AI-generated and is not live satellite or meteorological data.</p><a href="https://power.larc.nasa.gov/" target="_blank" rel="noopener noreferrer">NASA POWER data source ↗</a></div></section>
 </div>`);
}
'''
css_add = r'''
/* NOVAX LAB — Cinematic About Us artwork and responsive information */
.novax-about{display:flex;flex-direction:column;gap:20px}
.novax-about-hero{border:1px solid #1aab86;border-radius:22px;overflow:hidden;background:#03191e;box-shadow:0 16px 45px #0006}
.novax-about-hero img{display:block;width:100%;height:auto;aspect-ratio:1919/1079;object-fit:contain}
.novax-about-heading{background:linear-gradient(110deg,#0b3e3c,#09242e);border:1px solid #258a76;border-radius:20px;padding:24px;display:flex;justify-content:space-between;align-items:center;gap:18px}
.novax-about-heading h2{margin:6px 0;color:#fff;font-size:clamp(23px,2.5vw,34px)}
.novax-about-heading p{margin:8px 0 0;color:#c4e3d9;line-height:1.6}
.novax-about-columns{display:grid;grid-template-columns:1.55fr 1fr;gap:18px}
.novax-about-section,.novax-about-credits{border:1px solid #2b9d84;border-radius:20px;background:linear-gradient(135deg,#0b3c39,#06232b);padding:24px;box-shadow:0 10px 30px #0003}
.novax-about-section>h3{font-size:23px;color:#f4cd75;margin:0 0 20px}
.novax-team-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px}
.novax-team-card,.novax-goal{background:linear-gradient(120deg,#0b5148,#082c31);border:1px solid #288e77;border-radius:16px;display:flex;gap:12px;align-items:center;padding:16px;min-width:0}
.novax-team-card strong{font-size:16px;color:#fff;line-height:1.4;overflow-wrap:anywhere}
.novax-team-card p{font-size:14px;color:#f4cd75;margin:4px 0 0}
.novax-person-icon{display:grid;place-items:center;border:1px solid #31cba3;min-width:44px;width:44px;height:44px;border-radius:50%;font-size:26px;color:#aaffdc}
.novax-goals{display:flex;flex-direction:column;gap:12px}
.novax-goal>span{font-size:32px;min-width:46px;text-align:center}
.novax-goal p{color:#effff8;font-size:16px;line-height:1.5;margin:0}
.novax-about-credits{display:grid;grid-template-columns:1fr 1fr;gap:25px}
.novax-about-credits h3{color:#f5cf7b;margin:0 0 8px}
.novax-about-credits p{font-size:14px;color:#c9e9dc;line-height:1.7}
.novax-about-credits a{color:#65efc0;text-decoration:underline}
:root[data-theme="light"] .novax-about-section,:root[data-theme="light"] .novax-about-heading,:root[data-theme="light"] .novax-about-credits{background:#07332f;color:#fff}
@media(max-width:1100px){.novax-about-columns{grid-template-columns:1fr}.novax-about-heading{align-items:start;flex-direction:column}}
@media(max-width:650px){.novax-team-grid,.novax-about-credits{grid-template-columns:1fr}.novax-about-hero{border-radius:14px}.novax-about-section{padding:17px}.novax-team-card{padding:12px}.novax-team-card strong{font-size:15px}}
'''
# Only mutate after all validations succeeded.
backup = root / 'app.js.before-novax-about'
if not backup.exists(): shutil.copy2(app, backup)
s = s[:a] + new_about + s[b:]
app.write_text(s, encoding='utf-8')
with css.open('a',encoding='utf-8') as f: f.write('\n'+css_add+'\n')
dst.parent.mkdir(parents=True,exist_ok=True)
shutil.copy2(src,dst)
print('Installed Team NovaX Lab About Us hero, responsive team cards and objectives.')
print('Backup:',backup)
print('Next: npm run build && npm test')
